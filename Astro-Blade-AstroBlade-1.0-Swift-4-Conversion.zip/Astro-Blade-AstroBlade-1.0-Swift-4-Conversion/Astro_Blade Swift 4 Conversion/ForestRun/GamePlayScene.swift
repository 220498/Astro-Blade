import SpriteKit

class GamePlayScene: SKScene, SKPhysicsContactDelegate {
    
    var player = Player()
    let enemy  = SKSpriteNode(imageNamed: "enemy");
    let plat = SKSpriteNode(imageNamed: "platform")
     var lastBombAdded: TimeInterval = 0//a
    var lastplatformAdded: TimeInterval = 0//a
  //  var canJump = true
     let bombVelocity: CGFloat = 5.0//a
     let platformvelocity: CGFloat = 5.0//a
    
    let bombCategory = 0x1 << 1//a
    override func didMove(to view: SKView) {
        initialize()
        self.addBomb()
        self.addplatform()
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        // this will constanlty check to make sure background and grounds are visible
         movingBackgroundsAndGrounds()
        self.moveBomb()
        self.moveplatform()
        
        if currentTime - self.lastBombAdded > 1{
            self.lastBombAdded = currentTime + 1
            self.addBomb()
            
        }
        if currentTime - self.lastplatformAdded > 4{
            self.lastplatformAdded = currentTime + 1
            self.addplatform()
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        for touch in touches {
            
        _ = touch.location(in: self)
        
        player.jump()
        }
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
            var firstBody = SKPhysicsBody();
            var secondBody = SKPhysicsBody();
            
            if contact.bodyA.node?.name == "Player" {
                firstBody = contact.bodyA;
                secondBody = contact.bodyB;
            } else {
                firstBody = contact.bodyB;
                secondBody = contact.bodyA;
            }
        
        if firstBody.node?.name == "Player" && secondBody.node?.name == "Ground" {
          //  player.jump()
        }
        
            if firstBody.node?.name == "Player" && secondBody.node?.name == "Obstacle" {

            
        }
    }
    
    func initialize() {
        
        physicsWorld.contactDelegate = self
        createBackground()
        createGround()
        createPlayer()
        plat.setScale(1)
        plat.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        plat.position = CGPoint(x: 600, y: -350)
        self.addChild(plat)
       enemy.setScale(0.5);
        enemy.position = CGPoint(x: 600, y: -200)
        self.addChild(enemy)
    }
    
    // adds the player child to the scene
    func createPlayer() {
        player = Player(imageNamed: "Player 1");
        player.initialize();
        player.position = CGPoint(x: -30, y: -(self.frame.size.height / 2) + 160);
        self.addChild(player);
    }

    
    func createBackground() {
        // have to remember this for the infinite background scroller!!!
        for i in 0...2 {
        let background = SKSpriteNode(imageNamed: "GamePlayBackground")
        background.name = "GamePlayBackground"
        background.anchorPoint = CGPoint(x: 0.5, y: 0.5)
            // important to add the x value correctly here!!
        background.position = CGPoint(x: CGFloat(i) * background.size.width, y: 0)
        background.zPosition = -1
        
        self.addChild(background)
        }
        
    }
    
    func createGround() {
        
        for i in 0...2 {
        let ground = SKSpriteNode(imageNamed: "GamePlayGround")
        ground.name = "GamePlayGround"
        ground.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        ground.position = CGPoint(x: CGFloat(i) * ground.size.width, y: -(self.frame.size.height / 2))
        ground.setScale(1)
        ground.zPosition = 2
            
        //physicsbody stuff
            ground.physicsBody = SKPhysicsBody(rectangleOf: ground.size)
            ground.physicsBody?.affectedByGravity = false
            ground.physicsBody?.isDynamic = false
            ground.physicsBody?.categoryBitMask = Collider.Ground
        
        self.addChild(ground)
        }
    }
    
    func movingBackgroundsAndGrounds() {
        
  
        // to add the infinity moving backgrounds
        enumerateChildNodes(withName: "GamePlayBackground", using:  ({ (node, error) in
        
        let backgroundNode = node as! SKSpriteNode
        
        backgroundNode.position.x -= 8
        
        if backgroundNode.position.x < -(self.frame.width) {
            backgroundNode.position.x += backgroundNode.size.width * 3
        }
        
        }))
        
        enumerateChildNodes(withName: "GamePlayGround", using: ({ (node, error) in
            
            let groundNode = node as! SKSpriteNode
            
            // sets the speed of the scroller
            groundNode.position.x -= 2
            
            // if the ground position is less than the frames width, then add it X 3 so we never get grey
            if groundNode.position.x < -(self.frame.width) {
                groundNode.position.x += groundNode.size.width * 3
            }
            
        }))
        
    
        
    }


    func addBomb() {
        let bomb = SKSpriteNode(imageNamed: "blade")
        bomb.setScale(0.25)
        bomb.zRotation = 3.14/2
        bomb.physicsBody = SKPhysicsBody(rectangleOf: bomb.size)
        bomb.physicsBody?.isDynamic = true
        bomb.name = "bomb"
        bomb.physicsBody?.categoryBitMask = UInt32(bombCategory)
        //bomb.physicsBody?.contactTestBitMask = UInt32(shipCategory)
        bomb.physicsBody?.collisionBitMask = 0
        bomb.physicsBody?.usesPreciseCollisionDetection = true
        bomb.physicsBody?.affectedByGravity = false
        //let random: CGFloat = CGFloat(arc4random_uniform(300))
        bomb.position = CGPoint(x: 600, y: -200)
        bomb.zPosition = 1;
        self.addChild(bomb)
    }
    func moveBomb() {
        self.enumerateChildNodes(withName: "bomb", using: {(node, stop) -> Void in
            if let bomb = node as? SKSpriteNode {
                bomb.position = CGPoint(x: bomb.position.x - self.bombVelocity, y: bomb.position.y)

                if bomb.position.x < -800 {
                    bomb.removeFromParent()
                }
            }
        })
    }
    func addplatform() {
        let bomb = SKSpriteNode(imageNamed: "platform")
        bomb.setScale(1.5)
        bomb.physicsBody = SKPhysicsBody(rectangleOf: bomb.size)
        bomb.physicsBody?.isDynamic = true
        bomb.name = "bomb"
        bomb.physicsBody?.categoryBitMask = UInt32(bombCategory)
        //bomb.physicsBody?.contactTestBitMask = UInt32(shipCategory)
        bomb.physicsBody?.collisionBitMask = 0
        bomb.physicsBody?.usesPreciseCollisionDetection = true
        bomb.physicsBody?.affectedByGravity = false
        //let random: CGFloat = CGFloat(arc4random_uniform(300))
        bomb.position = CGPoint(x: 800, y: 00)
        bomb.zPosition = 1;
        self.addChild(bomb)
    }
    func moveplatform() {
        self.enumerateChildNodes(withName: "bomb", using: {(node, stop) -> Void in
            if let bomb = node as? SKSpriteNode {
                bomb.position = CGPoint(x: bomb.position.x - self.platformvelocity, y: bomb.position.y)
                
//                if bomb.position.x < -800 {
//                    bomb.removeFromParent()
//                }
            }
        })
    }
//    func didBegin(_ contact: SKPhysicsContact) {
//        var firstBody = SKPhysicsBody()
//        var secondBody = SKPhysicsBody()
//
//        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
//            firstBody = contact.bodyA
//            secondBody = contact.bodyB
//        }else {
//            firstBody = contact.bodyB
//            secondBody = contact.bodyA
//        }
//
////        if (firstBody.categoryBitMask & UInt32(shipCategory)) != 0 && (secondBody.categoryBitMask & UInt32(bombCategory)) != 0 {
////            ship.removeFromParent()
////            let gameOverScene = GameOverScene(size: self.size)
////            self.view?.presentScene(gameOverScene, transition: .doorway(withDuration: 1))
//
//    }
}









