//
//  MenuScene.swift
//  AstroBlade_2
//
//  Created by Shaw, Connor N on 4/13/18.
//  Copyright © 2018 Shaw, Connor N. All rights reserved.
//

/*

import UIKit
import SpriteKit
import GameplayKit

class MenuScene: SKScene {
    
    var playButton = SKSpriteNode()
    let playButtonTex = SKTexture(imageNamed: "play")
    
    override func didMove(to view: SKView) {
        
        playButton = SKSpriteNode(texture: playButtonTex)
        playButton.position = CGPoint(x: self.frame.midX, y: self.frame.midY)
        self.addChild(playButton)
        
        
        func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
            
            
            if let touch = touches.first as? UITouch {
                let pos = touch.location(in: self)
                let node = self.atPoint(pos)
                
                if node == playButton {
                        
                    let scene = SKScene(fileNamed: "GameScene") as! GameScene
                    scene.scaleMode = SKSceneScaleMode.aspectFill
                    view.presentScene(scene)
                        
                }
            }
        }
    }
}
 
 */


import SpriteKit

class MenuScene: SKScene {
    
    /* UI Connections */
    var buttonPlay: MSButtonNode!
    
    override func didMove(to view: SKView) {
        /* Setup your scene here */
        
        /* Set UI connections */
        buttonPlay = self.childNode(withName: "buttonPlay") as! MSButtonNode
        
        /* Setup button selection handler */
        buttonPlay.selectedHandler = { [unowned self] in
            
            if let view = self.view {
                
                // Load the SKScene from 'GameScene.sks'
                if let scene = SKScene(fileNamed: "GameScene") {
                    
                    // Set the scale mode to scale to fit the window
                    scene.scaleMode = .aspectFill
                    
                    // Present the scene
                    view.presentScene(scene)
                }
                
                // Debug helpers
                view.showsFPS = true
                view.showsPhysics = true
                view.showsDrawCount = true
            }
        }
        
    }
}
