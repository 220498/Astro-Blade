//
//  GameScene.swift
//  AstroBlade_2
//
//  Created by Shaw, Connor N on 4/13/18.
//  Copyright © 2018 Shaw, Connor N. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    var entities = [GKEntity]()
    var graphs = [String : GKGraph]()
    
    override func sceneDidLoad() {

        
        
    }
    
    
    func touchDown(atPoint pos : CGPoint) {
        
    
        
    }
    
    func touchMoved(toPoint pos : CGPoint) {
        
    
        
    }
    
    func touchUp(atPoint pos : CGPoint) {
        
    
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
      
        
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
       
        
    
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        
    
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    
        
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        
       
        
    }
}
